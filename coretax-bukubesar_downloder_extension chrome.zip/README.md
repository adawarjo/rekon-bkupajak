# Coretax Buku Besar Downloader

Extension Chrome untuk mengunduh **semua** transaksi Buku Besar di Coretax DJP
(https://coretaxdjp.pajak.go.id) per batch 500 baris, lalu disimpan sebagai CSV/JSON.

## Instalasi
1. Ekstrak zip ini ke sebuah folder.
2. Buka `chrome://extensions`, aktifkan **Developer mode** (pojok kanan atas).
3. Klik **Load unpacked**, pilih folder `coretax-bukubesar`.

## Cara pakai
1. Login ke Coretax, buka menu **Buku Besar** (Portal Saya → Buku Besar).
2. Atur filter (periode, jenis pajak, dll.) lalu klik **Cari** sehingga tabel tampil
   — sebaiknya masih di halaman pertama tabel.
3. Klik tombol biru **⬇ Buku Besar** di kanan bawah layar.
4. Pastikan sumber data yang bertanda ★ terpilih, limit = 500, lalu klik **Download CSV**.
5. Extension akan mengambil 500 baris per request (jeda 0,4 detik) sampai semua data terambil.

## Catatan
- Extension tidak menyimpan/mengirim data ke mana pun; semua request memakai sesi login Anda sendiri.
- Pemisah `;` cocok untuk Excel dengan regional Indonesia; pilih `,` untuk regional English.
- Jika server membatasi ukuran halaman di bawah 500, extension otomatis menyesuaikan.
- Jika muncul error HTTP 401/403, refresh halaman Coretax lalu tampilkan ulang tabelnya.
- Jika daftar sumber kosong, klik Cari / pindah halaman tabel sekali lagi agar request tertangkap.
