/*
 * Coretax Buku Besar Downloader
 * Berjalan di "MAIN world" halaman Coretax:
 * 1. Menyadap fetch/XHR untuk menemukan request tabel yang berpaginasi (mis. Buku Besar).
 * 2. Mengulang request tersebut dengan ukuran halaman = limit (default 500) sampai semua data terambil.
 * 3. Menyimpan hasilnya sebagai CSV.
 */
(() => {
  if (window.__ctxBukuBesar) return;
  window.__ctxBukuBesar = true;

  const DEFAULT_LIMIT = 500;
  const MAX_CAND = 30;
  const DELAY_MS = 400;
  const MAX_PAGES = 5000;

  const SIZE_KEYS = ['rows', 'pagesize', 'take', 'limit', 'size', 'perpage', 'maxresultcount', 'itemsperpage', 'length'];
  const OFF_KEYS = ['first', 'skip', 'offset', 'start', 'skipcount'];
  const PAGE_KEYS = ['page', 'pagenumber', 'pageindex', 'pageno', 'currentpage'];
  const TOTAL_RE = /^(total|totalcount|totalrecords?|recordstotal|totaldata|totalitems|totalrows?|rowcount|count)$/i;
  const HINT_RE = /ledger|buku.?besar|generalledger|taxpayeraccount/i;

  const candidates = [];
  const origFetch = window.fetch.bind(window);

  // ---------- helpers ----------
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const isNumLike = (v) => typeof v === 'number' || (typeof v === 'string' && /^\d+$/.test(v));

  function getAt(obj, path) {
    let cur = obj;
    for (const k of path) {
      if (cur == null) return undefined;
      cur = cur[k];
    }
    return cur;
  }

  function setAt(obj, path, val) {
    let cur = obj;
    for (let i = 0; i < path.length - 1; i++) cur = cur[path[i]];
    const last = path[path.length - 1];
    cur[last] = typeof cur[last] === 'string' ? String(val) : val;
  }

  function findPaging(obj, depth = 0, path = []) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj) || depth > 3) return null;
    const res = { sizePath: null, offPath: null, pagePath: null };
    for (const [k, v] of Object.entries(obj)) {
      const lk = k.toLowerCase();
      if (isNumLike(v)) {
        if (!res.sizePath && SIZE_KEYS.includes(lk)) res.sizePath = [...path, k];
        else if (!res.offPath && OFF_KEYS.includes(lk)) res.offPath = [...path, k];
        else if (!res.pagePath && PAGE_KEYS.includes(lk)) res.pagePath = [...path, k];
      } else if (v && typeof v === 'object' && !Array.isArray(v)) {
        const sub = findPaging(v, depth + 1, [...path, k]);
        if (sub) for (const key of Object.keys(res)) if (!res[key] && sub[key]) res[key] = sub[key];
      }
    }
    return res.sizePath ? res : null;
  }

  // Cari array data terbesar (utamakan array berisi objek)
  function findArray(obj) {
    let best = null;
    const walk = (o, path, depth) => {
      if (!o || typeof o !== 'object' || depth > 5) return;
      if (Array.isArray(o)) {
        const objs = o.length === 0 || typeof o[0] === 'object';
        const score = (objs ? 1e9 : 0) + o.length;
        if (!best || score > best.score) best = { path, score };
        return;
      }
      for (const [k, v] of Object.entries(o)) walk(v, [...path, k], depth + 1);
    };
    walk(obj, [], 0);
    return best ? best.path : null;
  }

  function findTotal(obj) {
    let found = null;
    const walk = (o, path, depth) => {
      if (found || !o || typeof o !== 'object' || Array.isArray(o) || depth > 4) return;
      for (const [k, v] of Object.entries(o)) {
        if (TOTAL_RE.test(k) && isNumLike(v)) { found = [...path, k]; return; }
      }
      for (const [k, v] of Object.entries(o)) walk(v, [...path, k], depth + 1);
    };
    walk(obj, [], 0);
    return found;
  }

  function absUrl(u) {
    try { return new URL(u, location.href).href; } catch { return u; }
  }

  // ---------- penangkapan request ----------
  async function inspect(req, getJson) {
    try {
      const url = absUrl(req.url);
      let source = null, reqObj = null, paging = null;

      if (req.body && typeof req.body === 'string') {
        try { reqObj = JSON.parse(req.body); } catch { reqObj = null; }
        if (reqObj) { paging = findPaging(reqObj); if (paging) source = 'json'; }
      }
      if (!paging) {
        const u = new URL(url);
        const q = {};
        u.searchParams.forEach((v, k) => { q[k] = v; });
        paging = findPaging(q);
        if (paging) { source = 'query'; reqObj = q; }
      }
      if (!paging) return;

      const json = await getJson();
      if (!json || typeof json !== 'object') return;
      const arrPath = findArray(json);
      if (!arrPath) return;
      const rows = getAt(json, arrPath) || [];
      const totalPath = findTotal(json);

      const key = req.method + ' ' + url.split('?')[0];
      const cand = {
        key, url, method: req.method, headers: req.headers || {}, source, reqObj,
        ...paging, arrPath, totalPath,
        sample: rows.length, total: totalPath ? Number(getAt(json, totalPath)) : null,
        time: Date.now(),
      };
      const idx = candidates.findIndex((c) => c.key === key);
      if (idx >= 0) candidates.splice(idx, 1);
      candidates.unshift(cand);
      if (candidates.length > MAX_CAND) candidates.pop();
      ui.refresh();
    } catch (e) { /* abaikan */ }
  }

  // fetch
  window.fetch = function (input, init) {
    const p = origFetch(input, init);
    try {
      init = init || {};
      const url = typeof input === 'string' ? input : (input && input.url) || String(input);
      const method = (init.method || (input && input.method) || 'GET').toUpperCase();
      const headers = {};
      new Headers(init.headers || (input instanceof Request ? input.headers : undefined))
        .forEach((v, k) => { headers[k] = v; });
      const body = typeof init.body === 'string' ? init.body : null;
      p.then((resp) => {
        if (!resp.ok) return;
        inspect({ url, method, headers, body }, () => resp.clone().json().catch(() => null));
      }).catch(() => {});
    } catch (e) { /* abaikan */ }
    return p;
  };

  // XHR (dipakai Angular HttpClient)
  const XO = XMLHttpRequest.prototype.open;
  const XS = XMLHttpRequest.prototype.send;
  const XH = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__ctx = { method: String(method).toUpperCase(), url: String(url), headers: {} };
    return XO.apply(this, arguments);
  };
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    if (this.__ctx) this.__ctx.headers[k] = v;
    return XH.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (body) {
    const ctx = this.__ctx;
    if (ctx) {
      ctx.body = typeof body === 'string' ? body : null;
      this.addEventListener('load', () => {
        if (this.status < 200 || this.status >= 300) return;
        inspect(ctx, async () => {
          try {
            if (this.responseType === 'json') return this.response;
            if (this.responseType === '' || this.responseType === 'text') return JSON.parse(this.responseText);
            if (this.responseType === 'blob') return JSON.parse(await this.response.text());
          } catch { return null; }
          return null;
        });
      });
    }
    return XS.apply(this, arguments);
  };

  // ---------- download ----------
  async function runDownload(c, limit, onProg, shouldStop) {
    const all = [];
    let total = null;
    let effLimit = limit;
    const pageBase = c.pagePath ? (Number(getAt(c.reqObj, c.pagePath)) === 0 ? 0 : 1) : 0;
    const canPage = !!(c.offPath || c.pagePath);

    for (let i = 0; i < MAX_PAGES; i++) {
      if (shouldStop()) throw new Error('Dibatalkan.');
      const obj = JSON.parse(JSON.stringify(c.reqObj));
      setAt(obj, c.sizePath, effLimit);
      if (c.offPath) setAt(obj, c.offPath, all.length);
      else if (c.pagePath) setAt(obj, c.pagePath, pageBase + i);

      let url = c.url, body;
      if (c.source === 'query') {
        const u = new URL(c.url);
        for (const [k, v] of Object.entries(obj)) u.searchParams.set(k, v);
        url = u.href;
      } else {
        body = JSON.stringify(obj);
      }

      const headers = { ...c.headers };
      delete headers['content-length'];
      delete headers['Content-Length'];
      const resp = await origFetch(url, { method: c.method, headers, body, credentials: 'include' });
      if (!resp.ok) throw new Error(`Server membalas HTTP ${resp.status}. Coba refresh halaman / login ulang.`);
      const json = await resp.json();
      const rows = getAt(json, c.arrPath) || [];
      if (total == null && c.totalPath) {
        const t = Number(getAt(json, c.totalPath));
        if (!Number.isNaN(t)) total = t;
      }

      // Jika server membatasi ukuran halaman di bawah limit, sesuaikan
      if (i === 0 && rows.length > 0 && rows.length < effLimit && total != null && total > rows.length) {
        effLimit = rows.length;
      }

      all.push(...rows);
      onProg(all.length, total, i + 1);

      if (rows.length === 0 || !canPage) break;
      if (total != null ? all.length >= total : rows.length < effLimit) break;
      await sleep(DELAY_MS);
    }
    return all;
  }

  function flatten(o, pre = '', out = {}) {
    for (const [k, v] of Object.entries(o || {})) {
      const key = pre ? `${pre}.${k}` : k;
      if (v && typeof v === 'object' && !Array.isArray(v)) flatten(v, key, out);
      else if (Array.isArray(v)) out[key] = JSON.stringify(v);
      else out[key] = v;
    }
    return out;
  }

  function toCSV(rows, sep) {
    const flat = rows.map((r) => (r && typeof r === 'object' ? flatten(r) : { value: r }));
    const cols = [];
    const seen = new Set();
    for (const r of flat) for (const k of Object.keys(r)) if (!seen.has(k)) { seen.add(k); cols.push(k); }
    const esc = (v) => {
      if (v == null) return '';
      const s = String(v);
      return /["\n\r]/.test(s) || s.includes(sep) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const lines = [cols.map(esc).join(sep)];
    for (const r of flat) lines.push(cols.map((c) => esc(r[c])).join(sep));
    return '\ufeff' + lines.join('\r\n');
  }

  function saveFile(content, name, type) {
    const blob = new Blob([content], { type });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.documentElement.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  }

  function stamp() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
  }

  // ---------- UI panel ----------
  const ui = (() => {
    let root, els, running = false, stop = false;

    function build() {
      if (root || !document.body) return;
      if (window !== window.top && candidates.length === 0) return;
      const host = document.createElement('div');
      host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;';
      root = host.attachShadow({ mode: 'open' });
      root.innerHTML = `
        <style>
          *{box-sizing:border-box;font-family:system-ui,Segoe UI,Arial,sans-serif;font-size:13px}
          .fab{background:#0b5394;color:#fff;border:0;border-radius:20px;padding:8px 14px;cursor:pointer;box-shadow:0 2px 8px #0004}
          .card{width:340px;background:#fff;color:#222;border-radius:10px;box-shadow:0 4px 18px #0005;padding:12px;display:none}
          .card.open{display:block}
          .hd{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;font-weight:600}
          .x{background:none;border:0;font-size:16px;cursor:pointer}
          label{display:block;margin:6px 0 2px;color:#555}
          select,input{width:100%;padding:5px;border:1px solid #bbb;border-radius:6px}
          .row{display:flex;gap:8px}.row>div{flex:1}
          .btns{display:flex;gap:8px;margin-top:10px}
          .btn{flex:1;padding:7px;border:0;border-radius:6px;cursor:pointer;background:#0b5394;color:#fff}
          .btn.sec{background:#e3e3e3;color:#222}
          .btn:disabled{opacity:.5;cursor:default}
          .st{margin-top:8px;color:#333;white-space:pre-wrap}
          .hint{color:#777;font-size:12px;margin-top:4px}
          .hbtn{background:#e8f0fa;color:#0b5394;border:0;border-radius:50%;width:22px;height:22px;font-weight:700;cursor:pointer;margin-right:4px}
          .help{display:none;background:#f6f9fc;border:1px solid #d6e2ef;border-radius:8px;padding:8px 10px;margin-bottom:8px;max-height:300px;overflow:auto}
          .help.open{display:block}
          .help h4{margin:6px 0 4px;font-size:13px;color:#0b5394}
          .help ol,.help ul{margin:0 0 6px;padding-left:18px}
          .help li{margin:2px 0;font-size:12px;line-height:1.4}
        </style>
        <button class="fab">⬇ Buku Besar</button>
        <div class="card">
          <div class="hd"><span>Download Buku Besar</span><span><button class="hbtn" title="Cara penggunaan">?</button><button class="x" title="Tutup">✕</button></span></div>
          <div class="help">
            <h4>Cara Penggunaan</h4>
            <ol>
              <li>Login Coretax, buka menu <b>Buku Besar</b> (Portal Saya → Buku Besar).</li>
              <li>Atur filter (periode, jenis pajak, dll.), lalu klik <b>Cari</b> sampai tabel tampil. Biarkan tabel di halaman pertama.</li>
              <li>Di panel ini, pilih <b>Sumber data</b> yang bertanda ★ (request Buku Besar).</li>
              <li>Isi <b>Limit per request</b> (default 500).</li>
              <li>Pilih <b>Pemisah CSV</b>: <b>;</b> untuk Excel regional Indonesia, <b>,</b> untuk regional English.</li>
              <li>Klik <b>Download CSV</b> (atau <b>JSON</b>). Tunggu sampai status “Selesai”. File tersimpan di folder Downloads.</li>
            </ol>
            <h4>Jika ada masalah</h4>
            <ul>
              <li><b>Daftar sumber kosong</b>: klik Cari atau pindah halaman tabel sekali lagi.</li>
              <li><b>Error HTTP 401/403</b>: sesi habis — refresh halaman / login ulang, lalu tampilkan tabel lagi.</li>
              <li><b>Data kurang</b>: ganti filter lalu Cari ulang sebelum download.</li>
              <li>Tombol <b>Stop</b> menghentikan proses yang sedang berjalan.</li>
            </ul>
          </div>
          <label>Sumber data (request yang tertangkap)</label>
          <select class="src"></select>
          <div class="hint">Buka menu Buku Besar lalu tampilkan datanya (klik Cari / pindah halaman) agar request tertangkap.</div>
          <div class="row">
            <div><label>Limit per request</label><input class="lim" type="number" min="1" value="${DEFAULT_LIMIT}"></div>
            <div><label>Pemisah CSV</label>
              <select class="sep"><option value=";">; (Excel Indonesia)</option><option value=",">, (koma)</option></select></div>
          </div>
          <div class="btns">
            <button class="btn go">Download CSV</button>
            <button class="btn sec json">JSON</button>
            <button class="btn sec stop" disabled>Stop</button>
          </div>
          <div class="st"></div>
        </div>`;
      document.body.appendChild(host);
      els = {
        fab: root.querySelector('.fab'), card: root.querySelector('.card'), x: root.querySelector('.x'),
        src: root.querySelector('.src'), lim: root.querySelector('.lim'), sep: root.querySelector('.sep'),
        go: root.querySelector('.go'), hbtn: root.querySelector('.hbtn'), help: root.querySelector('.help'), json: root.querySelector('.json'), stop: root.querySelector('.stop'),
        st: root.querySelector('.st'),
      };
      els.fab.onclick = () => { els.card.classList.add('open'); els.fab.style.display = 'none'; refresh(); };
      els.x.onclick = () => { els.card.classList.remove('open'); els.fab.style.display = ''; };
      els.hbtn.onclick = () => els.help.classList.toggle('open');
      els.go.onclick = () => start('csv');
      els.json.onclick = () => start('json');
      els.stop.onclick = () => { stop = true; };
      refresh();
    }

    function refresh() {
      if (!root) { build(); if (!root) return; }
      const prev = els.src.value;
      els.src.innerHTML = '';
      if (!candidates.length) {
        els.src.innerHTML = '<option value="">— belum ada request tertangkap —</option>';
        return;
      }
      const sorted = [...candidates].sort((a, b) =>
        (HINT_RE.test(b.url) - HINT_RE.test(a.url)) || (b.time - a.time));
      for (const c of sorted) {
        const o = document.createElement('option');
        o.value = c.key;
        const path = new URL(c.url).pathname.split('/').slice(-3).join('/');
        o.textContent = `${HINT_RE.test(c.url) ? '★ ' : ''}${c.method} …/${path}` +
          (c.total != null ? ` (total ${c.total})` : ` (${c.sample} baris)`);
        els.src.appendChild(o);
      }
      if (prev && candidates.some((c) => c.key === prev)) els.src.value = prev;
    }

    async function start(fmt) {
      if (running) return;
      const c = candidates.find((x) => x.key === els.src.value);
      if (!c) { els.st.textContent = 'Belum ada request. Tampilkan dulu data Buku Besar di halaman.'; return; }
      const limit = Math.max(1, parseInt(els.lim.value, 10) || DEFAULT_LIMIT);
      running = true; stop = false;
      els.go.disabled = els.json.disabled = true; els.stop.disabled = false;
      els.st.textContent = 'Mengambil data…';
      try {
        const rows = await runDownload(c, limit,
          (n, t, p) => { els.st.textContent = `Halaman ${p}: ${n}${t != null ? ' / ' + t : ''} baris`; },
          () => stop);
        if (!rows.length) { els.st.textContent = 'Tidak ada data yang dikembalikan server.'; return; }
        const base = `bukubesar_coretax_${stamp()}`;
        if (fmt === 'json') saveFile(JSON.stringify(rows, null, 2), base + '.json', 'application/json');
        else saveFile(toCSV(rows, els.sep.value), base + '.csv', 'text/csv;charset=utf-8');
        els.st.textContent = `Selesai: ${rows.length} baris tersimpan.`;
      } catch (e) {
        els.st.textContent = 'Gagal: ' + (e && e.message ? e.message : e);
      } finally {
        running = false;
        els.go.disabled = els.json.disabled = false; els.stop.disabled = true;
      }
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build);
    else build();
    return { refresh };
  })();
})();
